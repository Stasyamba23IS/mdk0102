﻿namespace Map
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Start1_img = new System.Windows.Forms.PictureBox();
            this.Medical_img = new System.Windows.Forms.PictureBox();
            this.Information_img = new System.Windows.Forms.PictureBox();
            this.Energy_Bars_img = new System.Windows.Forms.PictureBox();
            this.Drinks_img = new System.Windows.Forms.PictureBox();
            this.Toilets_img = new System.Windows.Forms.PictureBox();
            this.Interactive_Map = new System.Windows.Forms.PictureBox();
            this.Header = new System.Windows.Forms.Label();
            this.labelToilet = new System.Windows.Forms.Label();
            this.labelMedical = new System.Windows.Forms.Label();
            this.labelInformation = new System.Windows.Forms.Label();
            this.labelEnergy_bars = new System.Windows.Forms.Label();
            this.labelDrinks = new System.Windows.Forms.Label();
            this.Start2_img = new System.Windows.Forms.PictureBox();
            this.Start3_img = new System.Windows.Forms.PictureBox();
            this.Checkpoint1 = new System.Windows.Forms.Label();
            this.Checkpoint2 = new System.Windows.Forms.Label();
            this.Checkpoint3 = new System.Windows.Forms.Label();
            this.Checkpoint4 = new System.Windows.Forms.Label();
            this.Checkpoint5 = new System.Windows.Forms.Label();
            this.Checkpoint6 = new System.Windows.Forms.Label();
            this.Checkpoint7 = new System.Windows.Forms.Label();
            this.Checkpoint8 = new System.Windows.Forms.Label();
            this.Header2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Start1_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Medical_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Information_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Energy_Bars_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Drinks_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Toilets_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Interactive_Map)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start2_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start3_img)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Start1_img
            // 
            this.Start1_img.Image = global::Map.Properties.Resources.map_icon_start;
            this.Start1_img.Location = new System.Drawing.Point(203, 44);
            this.Start1_img.Margin = new System.Windows.Forms.Padding(2);
            this.Start1_img.Name = "Start1_img";
            this.Start1_img.Size = new System.Drawing.Size(56, 56);
            this.Start1_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Start1_img.TabIndex = 6;
            this.Start1_img.TabStop = false;
            this.Start1_img.Click += new System.EventHandler(this.Start1_img_Click);
            // 
            // Medical_img
            // 
            this.Medical_img.Image = global::Map.Properties.Resources.map_icon_medical;
            this.Medical_img.Location = new System.Drawing.Point(30, 358);
            this.Medical_img.Margin = new System.Windows.Forms.Padding(2);
            this.Medical_img.Name = "Medical_img";
            this.Medical_img.Size = new System.Drawing.Size(49, 45);
            this.Medical_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Medical_img.TabIndex = 5;
            this.Medical_img.TabStop = false;
            // 
            // Information_img
            // 
            this.Information_img.Image = global::Map.Properties.Resources.map_icon_information;
            this.Information_img.Location = new System.Drawing.Point(30, 292);
            this.Information_img.Margin = new System.Windows.Forms.Padding(2);
            this.Information_img.Name = "Information_img";
            this.Information_img.Size = new System.Drawing.Size(49, 45);
            this.Information_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Information_img.TabIndex = 4;
            this.Information_img.TabStop = false;
            // 
            // Energy_Bars_img
            // 
            this.Energy_Bars_img.Image = global::Map.Properties.Resources.map_icon_energy_bars;
            this.Energy_Bars_img.Location = new System.Drawing.Point(30, 104);
            this.Energy_Bars_img.Margin = new System.Windows.Forms.Padding(2);
            this.Energy_Bars_img.Name = "Energy_Bars_img";
            this.Energy_Bars_img.Size = new System.Drawing.Size(49, 45);
            this.Energy_Bars_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Energy_Bars_img.TabIndex = 3;
            this.Energy_Bars_img.TabStop = false;
            this.Energy_Bars_img.Click += new System.EventHandler(this.Energy_Bars_img_Click);
            // 
            // Drinks_img
            // 
            this.Drinks_img.Image = global::Map.Properties.Resources.map_icon_drinks;
            this.Drinks_img.Location = new System.Drawing.Point(30, 163);
            this.Drinks_img.Margin = new System.Windows.Forms.Padding(2);
            this.Drinks_img.Name = "Drinks_img";
            this.Drinks_img.Size = new System.Drawing.Size(49, 50);
            this.Drinks_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Drinks_img.TabIndex = 2;
            this.Drinks_img.TabStop = false;
            // 
            // Toilets_img
            // 
            this.Toilets_img.Image = global::Map.Properties.Resources.map_icon_toilets;
            this.Toilets_img.Location = new System.Drawing.Point(30, 225);
            this.Toilets_img.Margin = new System.Windows.Forms.Padding(2);
            this.Toilets_img.Name = "Toilets_img";
            this.Toilets_img.Size = new System.Drawing.Size(49, 49);
            this.Toilets_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Toilets_img.TabIndex = 1;
            this.Toilets_img.TabStop = false;
            // 
            // Interactive_Map
            // 
            this.Interactive_Map.Image = global::Map.Properties.Resources.map1;
            this.Interactive_Map.Location = new System.Drawing.Point(11, 11);
            this.Interactive_Map.Margin = new System.Windows.Forms.Padding(2);
            this.Interactive_Map.Name = "Interactive_Map";
            this.Interactive_Map.Size = new System.Drawing.Size(543, 539);
            this.Interactive_Map.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Interactive_Map.TabIndex = 0;
            this.Interactive_Map.TabStop = false;
            this.Interactive_Map.Click += new System.EventHandler(this.Interactive_Map_Click);
            // 
            // Header
            // 
            this.Header.AutoSize = true;
            this.Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Header.Location = new System.Drawing.Point(25, 53);
            this.Header.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(174, 26);
            this.Header.TabIndex = 7;
            this.Header.Text = "Название точки";
            this.Header.Click += new System.EventHandler(this.Header_Click);
            // 
            // labelToilet
            // 
            this.labelToilet.AutoSize = true;
            this.labelToilet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelToilet.Location = new System.Drawing.Point(103, 240);
            this.labelToilet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelToilet.Name = "labelToilet";
            this.labelToilet.Size = new System.Drawing.Size(62, 20);
            this.labelToilet.TabIndex = 8;
            this.labelToilet.Text = "Туалет";
            // 
            // labelMedical
            // 
            this.labelMedical.AutoSize = true;
            this.labelMedical.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelMedical.Location = new System.Drawing.Point(103, 372);
            this.labelMedical.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMedical.Name = "labelMedical";
            this.labelMedical.Size = new System.Drawing.Size(84, 20);
            this.labelMedical.TabIndex = 9;
            this.labelMedical.Text = "Медпункт";
            // 
            // labelInformation
            // 
            this.labelInformation.AutoSize = true;
            this.labelInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelInformation.Location = new System.Drawing.Point(100, 298);
            this.labelInformation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInformation.Name = "labelInformation";
            this.labelInformation.Size = new System.Drawing.Size(197, 20);
            this.labelInformation.TabIndex = 10;
            this.labelInformation.Text = "Информационный стенд";
            // 
            // labelEnergy_bars
            // 
            this.labelEnergy_bars.AutoSize = true;
            this.labelEnergy_bars.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelEnergy_bars.Location = new System.Drawing.Point(98, 121);
            this.labelEnergy_bars.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelEnergy_bars.Name = "labelEnergy_bars";
            this.labelEnergy_bars.Size = new System.Drawing.Size(218, 20);
            this.labelEnergy_bars.TabIndex = 11;
            this.labelEnergy_bars.Text = "Энергетические батончики";
            this.labelEnergy_bars.Click += new System.EventHandler(this.labelEnergy_bars_Click);
            // 
            // labelDrinks
            // 
            this.labelDrinks.AutoSize = true;
            this.labelDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelDrinks.Location = new System.Drawing.Point(103, 183);
            this.labelDrinks.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDrinks.Name = "labelDrinks";
            this.labelDrinks.Size = new System.Drawing.Size(74, 20);
            this.labelDrinks.TabIndex = 12;
            this.labelDrinks.Text = "Напитки";
            // 
            // Start2_img
            // 
            this.Start2_img.Image = global::Map.Properties.Resources.map_icon_start;
            this.Start2_img.Location = new System.Drawing.Point(69, 234);
            this.Start2_img.Margin = new System.Windows.Forms.Padding(2);
            this.Start2_img.Name = "Start2_img";
            this.Start2_img.Size = new System.Drawing.Size(56, 56);
            this.Start2_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Start2_img.TabIndex = 13;
            this.Start2_img.TabStop = false;
            this.Start2_img.Click += new System.EventHandler(this.Start2_img_Click);
            // 
            // Start3_img
            // 
            this.Start3_img.Image = global::Map.Properties.Resources.map_icon_start;
            this.Start3_img.Location = new System.Drawing.Point(338, 494);
            this.Start3_img.Margin = new System.Windows.Forms.Padding(2);
            this.Start3_img.Name = "Start3_img";
            this.Start3_img.Size = new System.Drawing.Size(56, 56);
            this.Start3_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Start3_img.TabIndex = 14;
            this.Start3_img.TabStop = false;
            this.Start3_img.Click += new System.EventHandler(this.Start3_img_Click);
            // 
            // Checkpoint1
            // 
            this.Checkpoint1.AutoSize = true;
            this.Checkpoint1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint1.Location = new System.Drawing.Point(334, 44);
            this.Checkpoint1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint1.Name = "Checkpoint1";
            this.Checkpoint1.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint1.TabIndex = 15;
            this.Checkpoint1.Text = "1";
            this.Checkpoint1.Click += new System.EventHandler(this.Checkpoint1_Click);
            // 
            // Checkpoint2
            // 
            this.Checkpoint2.AutoSize = true;
            this.Checkpoint2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint2.Location = new System.Drawing.Point(392, 201);
            this.Checkpoint2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint2.Name = "Checkpoint2";
            this.Checkpoint2.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint2.TabIndex = 16;
            this.Checkpoint2.Text = "2";
            this.Checkpoint2.Click += new System.EventHandler(this.Checkpoint2_Click);
            // 
            // Checkpoint3
            // 
            this.Checkpoint3.AutoSize = true;
            this.Checkpoint3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint3.Location = new System.Drawing.Point(381, 309);
            this.Checkpoint3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint3.Name = "Checkpoint3";
            this.Checkpoint3.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint3.TabIndex = 17;
            this.Checkpoint3.Text = "3";
            this.Checkpoint3.Click += new System.EventHandler(this.Checkpoint3_Click);
            // 
            // Checkpoint4
            // 
            this.Checkpoint4.AutoSize = true;
            this.Checkpoint4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint4.Location = new System.Drawing.Point(508, 432);
            this.Checkpoint4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint4.Name = "Checkpoint4";
            this.Checkpoint4.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint4.TabIndex = 18;
            this.Checkpoint4.Text = "4";
            this.Checkpoint4.Click += new System.EventHandler(this.Checkpoint4_Click);
            // 
            // Checkpoint5
            // 
            this.Checkpoint5.AutoSize = true;
            this.Checkpoint5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint5.Location = new System.Drawing.Point(307, 509);
            this.Checkpoint5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint5.Name = "Checkpoint5";
            this.Checkpoint5.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint5.TabIndex = 19;
            this.Checkpoint5.Text = "5";
            this.Checkpoint5.Click += new System.EventHandler(this.Checkpoint5_Click);
            // 
            // Checkpoint6
            // 
            this.Checkpoint6.AutoSize = true;
            this.Checkpoint6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint6.Location = new System.Drawing.Point(144, 451);
            this.Checkpoint6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint6.Name = "Checkpoint6";
            this.Checkpoint6.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint6.TabIndex = 20;
            this.Checkpoint6.Text = "6";
            this.Checkpoint6.Click += new System.EventHandler(this.Checkpoint6_Click);
            // 
            // Checkpoint7
            // 
            this.Checkpoint7.AutoSize = true;
            this.Checkpoint7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint7.Location = new System.Drawing.Point(95, 358);
            this.Checkpoint7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint7.Name = "Checkpoint7";
            this.Checkpoint7.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint7.TabIndex = 21;
            this.Checkpoint7.Text = "7";
            this.Checkpoint7.Click += new System.EventHandler(this.Checkpoint7_Click);
            // 
            // Checkpoint8
            // 
            this.Checkpoint8.AutoSize = true;
            this.Checkpoint8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Checkpoint8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Checkpoint8.Location = new System.Drawing.Point(84, 195);
            this.Checkpoint8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Checkpoint8.Name = "Checkpoint8";
            this.Checkpoint8.Size = new System.Drawing.Size(21, 24);
            this.Checkpoint8.TabIndex = 22;
            this.Checkpoint8.Text = "8";
            this.Checkpoint8.Click += new System.EventHandler(this.Checkpoint8_Click);
            // 
            // Header2
            // 
            this.Header2.AutoSize = true;
            this.Header2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Header2.Location = new System.Drawing.Point(25, 13);
            this.Header2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Header2.Name = "Header2";
            this.Header2.Size = new System.Drawing.Size(191, 26);
            this.Header2.TabIndex = 23;
            this.Header2.Text = "Номер чекпоинта";
            this.Header2.Click += new System.EventHandler(this.Header2_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.Energy_Bars_img);
            this.panel1.Controls.Add(this.Header2);
            this.panel1.Controls.Add(this.labelEnergy_bars);
            this.panel1.Controls.Add(this.Drinks_img);
            this.panel1.Controls.Add(this.labelDrinks);
            this.panel1.Controls.Add(this.Toilets_img);
            this.panel1.Controls.Add(this.labelToilet);
            this.panel1.Controls.Add(this.Information_img);
            this.panel1.Controls.Add(this.Medical_img);
            this.panel1.Controls.Add(this.labelMedical);
            this.panel1.Controls.Add(this.labelInformation);
            this.panel1.Controls.Add(this.Header);
            this.panel1.Location = new System.Drawing.Point(586, 44);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(371, 446);
            this.panel1.TabIndex = 24;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button1
            // 
            this.button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(341, 0);
            this.button1.Name = "button1";
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button1.Size = new System.Drawing.Size(30, 30);
            this.button1.TabIndex = 24;
            this.button1.Text = "x";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Checkpoint8);
            this.Controls.Add(this.Checkpoint7);
            this.Controls.Add(this.Checkpoint6);
            this.Controls.Add(this.Checkpoint5);
            this.Controls.Add(this.Checkpoint4);
            this.Controls.Add(this.Checkpoint3);
            this.Controls.Add(this.Checkpoint2);
            this.Controls.Add(this.Checkpoint1);
            this.Controls.Add(this.Start3_img);
            this.Controls.Add(this.Start2_img);
            this.Controls.Add(this.Start1_img);
            this.Controls.Add(this.Interactive_Map);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Карта";
            ((System.ComponentModel.ISupportInitialize)(this.Start1_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Medical_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Information_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Energy_Bars_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Drinks_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Toilets_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Interactive_Map)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start2_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start3_img)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Interactive_Map;
        private System.Windows.Forms.PictureBox Toilets_img;
        private System.Windows.Forms.PictureBox Drinks_img;
        private System.Windows.Forms.PictureBox Energy_Bars_img;
        private System.Windows.Forms.PictureBox Information_img;
        private System.Windows.Forms.PictureBox Medical_img;
        private System.Windows.Forms.PictureBox Start1_img;
        private System.Windows.Forms.Label Header;
        private System.Windows.Forms.Label labelToilet;
        private System.Windows.Forms.Label labelMedical;
        private System.Windows.Forms.Label labelInformation;
        private System.Windows.Forms.Label labelEnergy_bars;
        private System.Windows.Forms.Label labelDrinks;
        private System.Windows.Forms.PictureBox Start2_img;
        private System.Windows.Forms.PictureBox Start3_img;
        private System.Windows.Forms.Label Checkpoint1;
        private System.Windows.Forms.Label Checkpoint2;
        private System.Windows.Forms.Label Checkpoint3;
        private System.Windows.Forms.Label Checkpoint4;
        private System.Windows.Forms.Label Checkpoint5;
        private System.Windows.Forms.Label Checkpoint6;
        private System.Windows.Forms.Label Checkpoint7;
        private System.Windows.Forms.Label Checkpoint8;
        private System.Windows.Forms.Label Header2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
    }
}

